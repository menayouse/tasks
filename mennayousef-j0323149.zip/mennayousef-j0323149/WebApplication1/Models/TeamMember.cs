﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    public class TeamMember
    {
        [Key,DatabaseGenerated(DatabaseGeneratedOption.Identity)]
       public int MemberId { get; set; }
        [Required, MaxLength(100)]
        public string MemberName { get; set; }
        [Required,MaxLength(150)]
        public string Email { get; set; }
        [Required,MaxLength(50)]
        public string Role  {  get; set; }
        public List<task> Tasks { get; set; }
    }
}
