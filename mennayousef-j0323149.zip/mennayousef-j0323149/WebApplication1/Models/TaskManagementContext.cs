﻿using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models
{
    public class TaskManagementContext:DbContext
    {
        public DbSet<task> Tasks { get; set; }
        public DbSet<Project> Projects { get; set; }
        public DbSet<TeamMember> TeamMembers { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=FS-COMLAB3-PC11; Initial Catalog=Task_db; User Id=sa; Password=FIATS@2024");
            base.OnConfiguring(optionsBuilder);
        }
    }
}
