﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    public class task
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int TaskId { get; set; }
        [Required, MaxLength(100)]
        public string Title { get; set; }
        [Required, MaxLength(500)]
        public string Description { get; set; }
        [Required, MaxLength(50)]
        public string Status { get; set; }
        [Required, MaxLength(50)]
        public string Priority { get; set; }
        public DateTime DeadLine { get; set; }
        [ForeignKey("Project")]
        public int ProjectId { get; set; }
        [ForeignKey("TeamMember")]
        public int MemberId { get; set; }
        public Project Projects { get; set; }
        public TeamMember TeamMembers { get; set; }
    }
}
