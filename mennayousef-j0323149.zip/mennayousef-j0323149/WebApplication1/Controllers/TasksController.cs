﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Reflection;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class TasksController : Controller
    {
        TaskManagementContext context=new TaskManagementContext();
        public IActionResult Index()
        {
             List<task> tasks = context.Tasks.ToList();
            return View(tasks);
        }
        [HttpGet]
        public IActionResult Add() 
        { 
            return View();
        }
        [HttpPost]
        public IActionResult Add(task model )
        {
            var task = context.Tasks.FirstOrDefault(a => a.TaskId==model.TaskId);
            if (model == null)
            {
                ModelState.AddModelError("", "Invalid");
                return View(model);
            }
            else
            {
                context.Tasks.Add(model);
                context.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            var task = context.Tasks.FirstOrDefault(a => a.TaskId == id);
            return View(task);
        }
        [HttpPost]
        public IActionResult Update(task model,int id)
        {
            
            context.Update(model);
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            var task = context.Tasks.FirstOrDefault(x => x.TaskId == id);
            context.Tasks.Remove(task);
            return RedirectToAction("Index");
        }
    }
}
