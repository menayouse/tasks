﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;
using System.Runtime.CompilerServices;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class TeamMembersController : Controller
    {
        TaskManagementContext context = new TaskManagementContext();
        public IActionResult Index()
        {
            List <TeamMember> teams = context.TeamMembers.ToList();
            return View(teams);
        }
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Add( TeamMember model)
        {
            var member= context.TeamMembers.FirstOrDefault(x => x.MemberId == model.MemberId);
            if (model == null)
            {
                ModelState.AddModelError("", "Invalid");
                return View(model);
            }
            else
            {
                context.TeamMembers.Add(model);
                context.SaveChanges();
            }
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult Edit(int id) 
        {
            var teamMembers = context.TeamMembers.FirstOrDefault(a => a.MemberId == id);
            return View(teamMembers);
        }
        [HttpPost]
        public IActionResult Edit(TeamMember model , int id)
        {
            context.Update(model);
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Delete( int id)
        {
            var member1= context.TeamMembers.FirstOrDefault(x => x.MemberId == id);
            context.TeamMembers.Remove(member1);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Details(int id)
        {
            var tasks = context.TeamMembers.Where(a => a.MemberId == id).Include(a => a.Tasks).ToList();
            return View(tasks);
        }
    }
}
