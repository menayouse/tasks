﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class ProjectsController : Controller
    {
        TaskManagementContext context = new TaskManagementContext();
        public IActionResult Index()
        {
            List<Project> projects = context.Projects.ToList();
            return View(projects);
        }
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Add(Project model)
        {
            var proj =context.Projects.FirstOrDefault(a => a.ProjectId == model.ProjectId);
            if (model == null)
            {
                ModelState.AddModelError("", "Invalid");
                return View(model);
            }
            else
            {
                context.Projects.Add(model);
                context.SaveChanges();
            }
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult Edit(int id ) 
        { 
            var project = context.Projects.FirstOrDefault(a => a.ProjectId==id);
            return View(project);
        }
        [HttpPost]
        public IActionResult Edit(Project model, int id) 
        {
            context.Update(model);
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Delete( int id)
        {
            var project=context.Projects.FirstOrDefault(a => a.ProjectId==id);
            context.Projects.Remove(project);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Details(int id)
        {
            var tasks = context.Projects.Include(a => a.Tasks).FirstOrDefault(a => a.ProjectId == id);
            return View(tasks);
        }

    }
}
